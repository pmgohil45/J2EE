package com.mycompany.sqldemo;
import java.sql.*;
public class SqlDemo {

    public static void main(String[] args) {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/prakash","root","");
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from stud");
            while(rs.next())
            {
                String n = rs.getString("name");
                int num = rs.getInt("number");
                System.out.println("ID : " + rs.getInt("id"));
                System.out.println("Name : " + n);
                System.out.println("Contact : " + num);
            }
            rs.close();
            con.close();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}
